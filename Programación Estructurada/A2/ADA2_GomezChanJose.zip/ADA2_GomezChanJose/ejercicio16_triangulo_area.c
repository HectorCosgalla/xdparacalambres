/*triangulo_area*/
/*que lea la base (B) y la altura (H) de un tri�ngulo rect�ngulo,
determine e imprima su �rea. A= B x H/2*/
/*jose manuel gomez chan*/
#include <stdio.h> /*directivas del preprocesador*/

int main(void) {
	/*declaracion de variables*/
	float base, altura, area=0; /*las variables del triangulo*/
	/*entrada*/
	printf("ingrese la base del triangulo rectangulo\n");
	scanf("%f",&base); /*se lee el dato de la base*/
	printf("ingrese la altura del triangulo rectangulo\n");
	scanf("%f",&altura); /*se lee el dato de la altura*/
	/*proceso*/
	area=(base*altura)/2; /*se efectua la operacion para sacar el area*/
	/*salida*/
	printf("el area del triangulo rectangulo es %.2f",area);
	return 0;
}

