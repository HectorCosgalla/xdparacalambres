/*volumen.c*/
/*que determine e imprima el volumen de la tierra. Considerar
que es un esferoide V= 4/3 = PI * a (cuadrada) * b. D�nde: a = radio ecuatorial =
6378.137 kms, b = radio polar = 6356.752 kms.*/
/*jose manuel gomez chan*/
#include <stdio.h>
#include <math.h> /*directivas del preprocesador*/
/*se definen las constantes necesarias para la formula*/
#define PI 3.141592
#define A 6378.137
#define B 6356.752

int main(void) {
	/*declaracion de variable*/
	int b=2;
	float volumen=0; /*el dato del volumen*/
	/*proceso*/
	volumen=4/3*(PI*pow(A,b)*B);
	/*salida*/
	printf(" el volumen de la tierra es %f kms",volumen);
	return 0;
}

