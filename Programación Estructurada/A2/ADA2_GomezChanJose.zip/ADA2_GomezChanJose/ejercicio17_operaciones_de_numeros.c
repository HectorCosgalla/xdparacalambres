/*operaciones_de_numeros*/
/*que lea tres n�meros reales y que determine e imprima la
suma, resta, multiplicaci�n y divisi�n de los mismos*/
/*jose manuel gomez chan*/
#include <stdio.h> /*directivas del preprocesador*/

int main(void) {
	/*declaracion de variables*/
	float num1, num2, num3, suma=0, resta=0, div=0, mult=0;
	/*entrada*/
	printf("ingrese 3 numeros reales\n");
	scanf("%f %f %f",&num1,&num2,&num3); /*se leen los numeros*/
	/*proceso*/
	suma=num1+num2+num3; /*se hace la suma de los numeros reales*/
	resta=num1-num2-num3; /*se hace la resta de los numeros reales*/
	mult=num1*num2*num3; /*se hace la multiplicacion de los numeros reales*/
	div=num1/num2/num3; /*se hace la division de los numeros reales*/
	/*salida*/
	/*se imprimen los resultados*/
	printf("la suma de los 3 numeros es %.2f \n", suma);
	printf("la resta de los 3 numeros es %.2f \n", resta);
	printf("la multiplicaci�n de los 3 numeros es %.2f \n", mult);
	printf("la division de los 3 numeros es %.2f", div);
	return 0;
}

