#include <stdio.h>

/*
Nombre: Programa de reporte de personal
Descripcion: E.P. que permita leer una matriz de 3 x 3 elementos que contenga números enteros e indique si se trata de un cuadrado mágico. 
Dicho cuadrado mágico es cuando la sumatoria de los elementos es 15 por renglones, columnas y diagonales (principal e invertida).
Autor: Programadores Insomnes (Daniel Mendez)
Compilador: VS Code
Versi�n: 1.0
31/03/2022
*/

int main() {
    // Declaracion de variables
    int matriz[3][3], i, j;
    int sum = 0, sum1 = 0, sum2 = 0, flag = 0;
 
    // Entrada
    printf("Ingrese datos de la matriz:\n");
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            printf("Dato %dX%d:\t", i+1, j+1);
            scanf("%d", &matriz[i][j]);
        }
    }

    // Proceso
    // Evaluar diagonales
    for (i = 0; j < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            if (i == j)
            {
                sum += matriz[i][j];
            }
        }
    }
 
    // Evaluar filas
    for (i = 0; i < 3; i++)
    {
        sum1 = 0;
        for (j = 0; j < 3; j++)
        {
            sum1 += matriz[i][j];
        }
        if (sum == sum1)
        {
            flag = 1;
        }
        else
        {
         flag = 0;
        }
    }
 
    // Evaluar columnas
    for (i = 0; i < 3; i++) {
        sum2 = 0;
        for (j = 0; j < 3; j++)
        {
         sum2 += matriz[i][j];
        }
        if (sum == sum2)
            flag = 1;
        else 
        {
            flag = 0;
        }
    }
 
    // Salida
    if (flag == 1)
    {
        printf("\nEs un cuadrado magico");
    }
    else
    {
        printf("\nNo es un cuadrado magico");
    }
}
/*Q/A: El codigo del programa es correcto, sin embargo, hubo un error al declarar el valor de una constante (sum), la cual la declararon =0, lo que 
el programa no funciones de manera adecuada. 
Ejemplo: *insertamos los datos de un cuadrado mágico*
Ingrese datos de la matriz:
Dato 1X1:       8
Dato 1X2:       1
Dato 1X3:       6
Dato 2X1:       3
Dato 2X2:       5
Dato 2X3:       7
Dato 3X1:       4
Dato 3X2:       9
Dato 3X3:       2

No es un cuadrado magico
Revisado por: Ángel Adrián Chan Puc (Los ensambladores)*/