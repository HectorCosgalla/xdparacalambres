#include <stdio.h>
#include <conio.h>
#include <locale.h>

/*
Nombre: 4
Descripci�n: P. que lea una matriz A de n x m elementos, as� como un vector X de n elementos 
que contengan n�meros reales. Calcular el producto de matriz por vector columna: el producto
de la matriz A por el vector X. Imprimir la matriz A, el vector X y el vector Z, cada arreglo a un lado del otro.
Autor: Aaron Graniel
Version: Zinjai
Fecha: 30/03/2022
*/

void leo_arreglos(int filas, int columnas, int A[][columnas], int elementos, int X[]);
void producto(int filas, int columnas, int elementos, int A[][columnas], int X[], int Z[]);
void imprimir_matrices(int filas, int columnas, int elementos, int A[][columnas], int X[], int Z[]);

int main(void) {
	setlocale(LC_ALL," ");
	
	int filas, columnas, elementos;
	
	/*Entrada*/	
	printf("Ingrese el n�mero de filas de la matriz A: ");
	scanf("%d", &filas);
	printf("Ingrese el n�mero de columnas de la matriz A: ");
	scanf("%d", &columnas);
	
	printf("\n");
	
	printf("Ingrese el n�mero de elementos del vector X: ");
	scanf("%d", &elementos);

	/*Proceso*/
	int A[filas][columnas];
	int X[elementos];
	int Z[filas];
	
	printf("\n");
	
	if(columnas==elementos){
		
		leo_arreglos(filas,columnas,A,elementos,X);//Entrada
		
		producto(filas, columnas, elementos,A, X, Z);//Proceso
		
		printf("\n");
		
		imprimir_matrices(filas,columnas,elementos,A,X,Z);//Salida
	}
	else{
		printf("El n�mero de columnas de la matriz A deben ser igual al n�mero de elementos del vector X para que se puedan multiplicar.");
	}
	
	getch();
	return 0;
}

/*Entrada*/
void leo_arreglos(int filas, int columnas,int A[][columnas], int elementos, int X[]){
	int i, j;
	for(i=0;i<filas;i++){
		for(j=0;j<columnas;j++){
			printf("Ingrese el elemento (%d,%d) de la matriz A: ", i+1, j+1);
			scanf("%d", &A[i][j]);
		}
	}
	
	printf("\n");
	
	for(j=0;j<elementos;j++){
		printf("Ingrese el elemento (%i) del vector X: ", j+1);
		scanf("%d", &X[j]);
	}
	
}
	
/*Proceso*/
/*Se determina el vector Z, la cual es el resultado de multiplicar la matriz A y el vector X*/
void producto(int filas, int columnas, int elementos, int A[][columnas], int X[], int Z[]){
	int i, j,sum;
	for(i=0;i<filas;i++){
		sum=0;
		for(j=0;j<columnas;j++){
			sum+=A[i][j]*X[j];
		}
		Z[i]=sum;
	}
}
	
/*Salida*/
/*Se imprimen la matriz y los dos vectores, X y Z, uno al lado del otro*/
void imprimir_matrices(int filas, int columnas, int elementos, int A[][columnas], int X[], int Z[]){

	int i, j;
	for(i=0;i<filas;i++){
		fflush(stdin);
		for(j=0;j<columnas;j++){
			printf("%d  ", A[i][j]);
		}
		printf("\t");
		
		if(i<1){
			for(j=0;j<elementos;j++){
				printf("%d  ", X[j]);
			}
		}
		
		printf("\t");
		
		if(i<1){
			for(j=0;j<filas;j++){
				printf("%d  ", Z[j]);
			}
		}
		printf("\n");
	}
}
/*
QA: Test 1: El programa funciona correctamente, se ingres� la longitud de la matriz y la longitud del vector
diferente al numero de columnas de la matriz y sali� un mensaje indicando error.
	Test 2: El programa imprime lo esperado, se ingresan los datos indicados y el programa realiza el producto
	arrojando un resultado correcto.
	
	conclusion: El programa si realiza lo que se necesita, se encuentra bien identado y comentado.
	
	Revisado por Jes�s Oswaldo Chan Uicab
*/
