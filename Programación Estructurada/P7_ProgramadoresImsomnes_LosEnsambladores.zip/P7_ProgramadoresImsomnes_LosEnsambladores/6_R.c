#include <stdio.h>
#include <conio.h>
#include <locale.h>
/*
Nombre: 6
Descripci�n: P. que lea las matrices A y B y si es posible, determinar e imprimir dichas matrices A y B, 
as� como la matriz P, (resultado de su multiplicaci�n); cada arreglo a un lado del otro.
Autor: Aaron Graniel
Version: Zinjai
Fecha: 29/03/2022
*/


void leo_matrices(int filas_A, int columnas_A, int filas_B, int columnas_B, int A[][columnas_A], int B[][columnas_B]);
void producto(int filas_A, int columnas_A, int columnas_B, int C[][columnas_B], int A[][columnas_A], int B[][columnas_B]);
void imprimir_matrices(int filas_A, int columnas_A, int filas_B, int columnas_B, int C[][columnas_B], int A[][columnas_A], int B[][columnas_B]);

int main(void) {
	setlocale(LC_ALL," ");
	
	int filas_A, filas_B, columnas_A, columnas_B;
	
	/*Entrada*/	
	printf("Ingrese el n�mero de filas de la matriz A: ");
	scanf("%d", &filas_A);
	printf("Ingrese el n�mero de columnas de la matriz A: ");
	scanf("%d", &columnas_A);
	
	printf("\n");
	
	printf("Ingrese el n�mero de filas de la matriz B: ");
	scanf("%d", &filas_B);
	printf("Ingrese el n�mero de columnas de la matriz B: ");
	scanf("%d", &columnas_B);
	
	/*Proceso*/
	int A[filas_A][columnas_A];
	int B[filas_B][columnas_B];
	int C[filas_A][columnas_B];
	
	printf("\n");
	
	if(columnas_A==filas_B){
		
		leo_matrices(filas_A,columnas_A,filas_B,columnas_B,A,B);//Entrada
		
		producto(filas_A, columnas_A, columnas_B, C, A, B);//Proceso
		
		printf("\n");
		
		imprimir_matrices(filas_A,columnas_A,filas_B,columnas_B,C,A,B);//Salida
	}
	else{
		printf("El n�mero de columnas de la matriz A deben ser igual al n�mero de filas de la matriz B");
	}
	
	getch();
	return 0;
}

/*Entrada*/
void leo_matrices(int filas_A, int columnas_A, int filas_B, int columnas_B, int A[][columnas_A], int B[][columnas_B]){
	int i, j;
	for(i=0;i<filas_A;i++){
		for(j=0;j<columnas_A;j++){
			printf("Ingrese el elemento (%d,%d) de la matriz A: ", i+1, j+1);
			scanf("%d", &A[i][j]);
		}
	}
	
	printf("\n");
	
	for(i=0;i<filas_B;i++){
		for(j=0;j<columnas_B;j++){
			printf("Ingrese el elemento (%d,%d) de la matriz B: ", i+1, j+1);
			scanf("%d", &B[i][j]);
		}
	}
	
}
	
/*Proceso*/
/*Se determina la matriz P, la cual es el resultado de multiplicar las matrices A y B*/
void producto(int filas_A, int columnas_A, int columnas_B, int C[][columnas_B], int A[][columnas_A], int B[][columnas_B]){
	int i, j, f, sum;
	for(i=0;i<filas_A;i++){
		for(f=0;f<columnas_B;f++){
			sum=0;
			for(j=0;j<columnas_A;j++){
				sum+=A[i][j]*B[j][f];
			}
			C[i][f]=sum;
		}
	}
}

/*Salida*/
/*Se imprimen las 3 matrices, uno al lado de la otra*/
void imprimir_matrices(int filas_A, int columnas_A, int filas_B, int columnas_B, int C[][columnas_B], int A[][columnas_A], int B[][columnas_B]){

	int i, j;
	for(i=0;;i++){
		fflush(stdin);
		if(i<filas_A){
			for(j=0;j<columnas_A;j++){
				printf("%d ", A[i][j]);
			}
		}
		else{
			printf("\t");
		}
		
		printf("\t");
		
		if(i<filas_B){
			for(j=0;j<columnas_B;j++){
				printf("%d ", B[i][j]);
			}
		}

		printf("\t");
		
		if(i<filas_A){
			for(j=0;j<columnas_B;j++){
				printf("%d ", C[i][j]);
			}
		}
		printf("\n");
		
		if(i>=filas_A&&i>=filas_B){
			break;
		}
	}
}

	
//Q.A. Se ejecuta el programa sin errores. En la linea 14, 15 y 16 se indican las funciones respectivamente  en orden, donde se leen las matrices,
//se realiza la operaciones correspondientes (multiplicacion y suma) y se imprimen las tres matrices..
//Se inicia en la linea 18, se agrega en la 19 el SETLOCALE para que no imprima caracteres especiales en vez de letras y se definen el tipo de datos que tendran las matrices..
//Se leen los datos de cuantas filas y columnas tendra cada matriz en la linea 25,27,32 y 34; en la linea 37,38 y 39 se definen las es matrices y en la linea 43 se agrega un IF
//para validar que el numero de columnas de la matriz A sea igual al numero de filas de la matriz B, en caso de ser asi, se llaman a las funciones antes mencionada.
// En la linea 53 se agrega un ELSE para que en caso de que no se cumpla la conidicion del IF , imprimira que el numero de columnas no es igual al de filas.
//En la linea 62,84 y 99 se detallan las funciones, en la primera se leen los datos que tendran las matrices, en la segunda se detallan las operaciones 
// de multiplicar y luego sumar en la linea 90, para luego guardar los datos en la linea 92, se agregan tres for, uno para ir de izquierda a derecha, luego para ir de abajo a arriba
//y de nuevo para ir de izquierda a derecha. En la linea 99 se detalla la ultima funcion la cual realiza la impresion de las tres matrices (A, B y la resultante de las operaciones).
//En la linea 125 se imprime la matriz resultante, ya que en la variable | C[i][j]| se habian guardado cada uno de los resultados..
//Se realiza la primera prueba donde se ingresa que el numero de columnas de la matriz A es diferente al numero de filas de la matriz B, e imprime el texto correspondiente.
//Se realiza la segunda prueba, se indica que las dos matrices seran de 3x3 y se anexan los datos correspondientes, matriz A1,2,3,4,5,6,7,8,9} y 
//la matriz B{9,8,7,6,5,4,3,2,1}
//Se imprime la matriz resultante P=30,24,18,84,69,54,138,114,90={[(1*9=9)+(2*6=12)+(3*3=9)=30],[(1*8=8)+(2*5=10)+(3*2=6)]24,[(1*7=7)+(2*4=8)+(3*1=3)]=18,[(4*9=39)+(5*6=30)+(6*3=18)]=84,
//[4*8=32)+(5*5=25)+(6*2=12)]=69,[4*7=28)+(5*4=20)+(6*1=6)]=54,[(7*9=63)+(8*6=48)+(9*3=27)]=138
//[(7*8=56)+(8*5=40)+(9*2=18)]=114,[(7*7=49)+(8*4=32)+(9*1=9)]=90} la cual es correcta.
//Revisado por Joaquin Roberto Gutierrez Ramirez.
