#include <stdio.h>

/* 2. E.P. que lea un arreglo de estructuras de n elementos, que contenga el nombre, peso, estatura y edad de n personas; 
se desea imprimir la información de aquellas personas que cuenten con edad mayor al promedio de grupo; 
también determinar el peso, la estatura y edad promedio de dichas personas, así como generar un reporte similar al ejercicio #1.
Autor: Programadores Insomnes, Adiel Elioenai Herrera Herrera
Version: 1
Fecha: 31/03/22*/
	
int main(int argc, char *argv[]) {

	int n, i,num=0;
	float edadp=0,estaturap=0,edadp2=0,pesop=0;

	printf("�..:");
	scanf("%d",&n);

	struct persona{
		char nombre[50];
		float peso;
		float estatura;
		int edad;
	}personas[n];

	for (i=0;i<n;i++)
	{
		printf("Nombre, persona %d: ",i+1);
		scanf("%s",&personas[i].nombre);
		printf("Peso, persona %d: ",i+1);
		scanf("%f",&personas[i].peso);
		printf("Estatura, persona %d: ",i+1);
		scanf("%f",&personas[i].estatura);
		printf("Edad, persona %d: ",i+1);
		scanf("%d",&personas[i].edad);
		edadp=edadp+personas[i].edad;
	}
	edadp=edadp/n;

	for (i=0;i<n;i++)
	{
		if (personas[i].edad>edadp)
		{
			estaturap=estaturap+personas[i].estatura;
			edadp2=edadp2+personas[i].edad;
			pesop
	    =pesop
	    +personas[i].peso;
		num=num+1;
		}
	}

	estaturap=estaturap/num;
	edadp2=edadp2/num;
	pesop=pesop/num;
	printf("\nNombre	 Peso(kg)	   Estatura(cm)	   Edad	      \n");
	printf("------------------------------------------------------------------------------------------------------------------\n");
	
	for (i=0;i<n;i++)
	{
		if (personas[i].edad>edadp)
		{
			printf("%s	%f	%f	%d	\n",personas[i].nombre,personas[i].peso,personas[i].estatura,personas[i].edad);
		}
	}
	printf("------------------------------------------------------------------------------------------------------------------\n");
	printf("Promedio:	%f	%f	%f	\n",pesop,estaturap,edadp2);
	
	return 0;
}

/* QA: El programa funciona sin ningun error, arroja los resultados correctamente
aunuque se recomienda no usar tantos ceros para los numeros tipo flotante.
Revisado por: Los Ensabladores*/
