/*
Nombre: Ejercicio 3
Descripci�n: E.P. que lea una matr�z de n x m elementos que contenga n�meros reales 
(PUEDEN SER ENTEROS),determine su matriz transpuesta e imprima ambas, una al lado de la otra 
(si son cuadradas y mismo tama�o) o una matriz abajo de la otra (en cualquier otro caso). 
De tal forma, la traspuesta de una matriz de orden m x n es una matriz de orden n x m, 
que se obtiene intercambiando filas por columnas; es decir, el elemento A(i,j) se coloca en B(j,i).
Autor: Reynaldo Couoh Martin
Version: Zinjai
Fecha: 31/03/2022
*/
#include <stdio.h>

int main() {
	/*Declaracion de variables*/
	int i, j;
	int n, m;
	
	/*Se le pide al usuario las dimensiones de la matriz*/
	printf("Ingrese el n�mero de filas que tendr� la matriz: ");
	scanf("%d", &n);
	printf("Ingrese el n�mero de columnas que tendr� la matriz: ");
	scanf("%d", &m);
	float matriz[n][m];
	float transpuesta[m][n];
	for (i=0; i<n; i++){
		for(j=0;j<m; j++){
			printf("Ingrese el elmento [%d][%d]: ", i+1, j+1);
			scanf("%f", &matriz[i][j]);
			transpuesta[j][i]=matriz[i][j];
		}
	}
	
	printf("La matriz que ingresaste fue:\n");
	/*ciclo para imprimir la matriz*/
	for (i=0; i<n; i++){
		for (j=0; j<m; j++){
			printf("%2.f ", matriz[i][j]);
		}
		printf("\n");
	}
	
	/*Se imprime la matriz transpuesta*/
	printf("La matriz transpuesta es:\n");
	for (i=0; i<n; i++){
		for (j=0; j<m; j++){
			printf("%2.f ", transpuesta[i][j]);
		}
		printf("\n");
	}
	
	 
	return 0;
}
/*Q/A: El programa no funciona correctramente para matrices con filas y columas diferentes, ya que,
no imprime su matriz transpuesta de manera correcta, cambia los valores y no cambia el numero de filas
ni de columnas, sin embargo, para matrices con filas y columnas iguales si imprime su matriz trasnpuesta
pero no lado a lado, lo cual se pidio en la descripcion del programa. Me parece que es error de la estructura 
repetitiva for al imprimir la metriz transpuesta. Asmimismo, considero que se puede agregar la libreria 
para los acentos, o usar el codigo ascii. Respecto al codigo me parece ordenado y bien identado, al igual
que sencillo de leer. 
Revisado por: Andrea Margarita Mendoza Tec.*/
